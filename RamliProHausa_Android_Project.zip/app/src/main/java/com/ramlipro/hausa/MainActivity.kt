package com.ramlipro.hausa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val Forest = Color(0xFF073B2A)
private val Gold = Color(0xFFD7B45A)
private val Cream = Color(0xFFF7F4EA)
private val Ink = Color(0xFF17251F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RamliApp() }
    }
}

data class Reading(val question: String, val figures: List<String>, val note: String)

@Composable
fun RamliApp() {
    var page by remember { mutableStateOf("Gida") }
    var question by remember { mutableStateOf("") }
    var latest by remember { mutableStateOf<Reading?>(null) }
    var history by remember { mutableStateOf(listOf<Reading>()) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Forest, secondary = Gold, background = Cream,
            surface = Color.White, onPrimary = Color.White, onBackground = Ink
        )
    ) {
        Scaffold(
            containerColor = Cream,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val items = listOf("Gida", "Fara Ramli", "Tarihi", "Saituna")
                    val icons = listOf(Icons.Default.Home, Icons.Default.AutoAwesome,
                        Icons.Default.History, Icons.Default.Settings)
                    items.forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Icon(icons[i], contentDescription = item) },
                            label = { Text(item, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            when (page) {
                "Gida" -> HomeScreen(Modifier.padding(padding), onStart = { page = "Fara Ramli" }, onHistory = { page = "Tarihi" })
                "Fara Ramli" -> ReadingScreen(
                    Modifier.padding(padding), question, { question = it }, latest,
                    onGenerate = {
                        val r = makeReading(question.ifBlank { "Tunani na yau" })
                        latest = r
                        history = listOf(r) + history
                    }
                )
                "Tarihi" -> HistoryScreen(Modifier.padding(padding), history)
                else -> SettingsScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier, onStart: () -> Unit, onHistory: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text("RAMLI PRO", color = Forest, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("Assalamu alaikum", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("Jagorar ramli cikin Hausa", color = Color.Gray, fontSize = 15.sp)
        }
        item {
            Column(
                Modifier.fillMaxWidth().background(Forest, RoundedCornerShape(24.dp)).padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(Icons.Default.AutoAwesome, null, tint = Gold, modifier = Modifier.size(34.dp))
                Text("Bincika alamomi", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("Ƙirƙiri tsarin alamomi sannan ka karanta bayanin al'ada.", color = Color.White.copy(alpha = .85f))
                Button(onClick = onStart, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Forest)) {
                    Text("Fara Ramli", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, null)
                }
            }
        }
        item { FeatureRow(Icons.Default.WifiOff, "Aiki ba tare da intanet ba", "Babban aikin ramli yana aiki a cikin wayarka.") }
        item { FeatureRow(Icons.Default.History, "Tarihin bincike", "Duba sakamakon da ka ƙirƙira yayin wannan zaman.") }
        item { FeatureRow(Icons.Default.MenuBook, "Koyon alamomi", "Karanta bayanin alamomi a cikin Hausa.") }
        item {
            OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.History, null); Spacer(Modifier.width(8.dp)); Text("Buɗe tarihi")
            }
        }
        item { Disclaimer() }
    }
}

@Composable
fun FeatureRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, body: String) {
    Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Forest, modifier = Modifier.size(30.dp))
        Spacer(Modifier.width(14.dp))
        Column { Text(title, fontWeight = FontWeight.Bold, color = Ink); Text(body, color = Color.Gray, fontSize = 13.sp) }
    }
}

@Composable
fun ReadingScreen(
    modifier: Modifier, question: String, onQuestion: (String) -> Unit,
    reading: Reading?, onGenerate: () -> Unit
) {
    LazyColumn(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Fara Ramli", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Forest) }
        item { Text("Rubuta tambaya ko niyya (zaɓi ne).", color = Color.Gray) }
        item {
            OutlinedTextField(
                value = question, onValueChange = onQuestion, modifier = Modifier.fillMaxWidth(),
                label = { Text("Tambayarka") }, placeholder = { Text("Misali: Ina son yin tunani kan wani zaɓi") },
                minLines = 2, shape = RoundedCornerShape(16.dp)
            )
        }
        item {
            Button(onClick = onGenerate, modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Forest)) {
                Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Samar da alamomi")
            }
        }
        if (reading != null) {
            item {
                Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Tsarin alamomi", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Forest)
                    reading.figures.forEachIndexed { i, f ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}.", fontWeight = FontWeight.Bold, color = Gold)
                            Spacer(Modifier.width(10.dp))
                            Text(f, fontSize = 21.sp, letterSpacing = 3.sp, color = Forest)
                            Spacer(Modifier.width(10.dp))
                            Text(if (f.count { it == '•' } % 2 == 0) "Ma'auni" else "Motsi", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                    Divider()
                    Text("Bayanin tunani", fontWeight = FontWeight.Bold, color = Ink)
                    Text(reading.note, color = Ink)
                    Text("Wannan fassara ta nishaɗi da tunani ce; ba ta tabbatar da abin da zai faru ba.", fontSize = 12.sp, color = Color.Gray)
                }
            }
        }
        item { Disclaimer() }
    }
}

fun makeReading(q: String): Reading {
    val figures = (1..4).map {
        val lines = (1..4).map { if (Random.nextBoolean()) "•" else "••" }
        lines.joinToString("  ")
    }
    val notes = listOf(
        "Ka ɗauki lokaci ka fayyace abin da ya fi muhimmanci a gare ka. Ka auna zaɓuɓɓukanka bisa bayanan da ka sani.",
        "Wannan tsari na iya zama tunatarwa don duba abin da za ka iya sarrafawa da abin da ke buƙatar ƙarin bayani.",
        "Ka yi tunani kan mataki ƙarami kuma mai amfani. Idan batun yana da muhimmanci, ka nemi shawara daga amintaccen mutum.",
        "Ka rubuta fa'idodi da haɗarin kowane zaɓi kafin yanke shawara. Alamomin nan ba hujja ba ne game da makoma."
    )
    return Reading(q, figures, notes.random())
}

@Composable
fun HistoryScreen(modifier: Modifier, history: List<Reading>) {
    LazyColumn(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Tarihi", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Forest) }
        if (history.isEmpty()) item { Text("Ba a ƙirƙiri wani ramli a wannan zaman ba tukuna.", color = Color.Gray) }
        items(history.size) { index ->
            val r = history[index]
            Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(16.dp)) {
                Text(r.question, fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.height(6.dp))
                Text(r.figures.joinToString("   /   "), color = Forest)
                Text(r.note, color = Color.Gray, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun SettingsScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Saituna", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Forest)
        FeatureRow(Icons.Default.Language, "Harshe", "Hausa")
        FeatureRow(Icons.Default.PhoneAndroid, "Yanayin amfani", "Offline: ana sarrafa alamomi a cikin waya")
        FeatureRow(Icons.Default.Security, "Sirri", "Wannan samfurin farko ba ya buƙatar izinin intanet.")
        Text("Sigar 1.0.0 • Ramli Pro Hausa", color = Color.Gray, fontSize = 12.sp)
        Disclaimer()
    }
}

@Composable
fun Disclaimer() {
    Text(
        "Lura: Ramli Pro kayan tunani da bayanin al'ada ne kawai. Ba ya tabbatar da makoma, ba ya bayar da shawarar kuɗi ko lafiya, kuma ba ya maye gurbin shawarar ƙwararre.",
        color = Color.Gray, fontSize = 12.sp, lineHeight = 17.sp
    )
}
