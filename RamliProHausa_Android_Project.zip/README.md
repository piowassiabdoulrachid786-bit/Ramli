# Ramli Pro Hausa — Android MVP

## Abin da ke ciki
- Android app na Kotlin + Jetpack Compose
- Shafin gida, samar da alamomi, tarihi na zaman yanzu, da saituna
- Babban aikin ramli yana aiki offline; babu izinin intanet a wannan MVP
- Hausa UI da bayanin cewa fassara ba tabbacin makoma ba ce

## Muhimmin iyaka
Wannan shi ne farkon samfurin aiki (MVP), ba cikakken tsarin ramli na gargajiya da aka tabbatar da ƙa'idodinsa ba. Alamomi suna samuwa ta bazuwar even/odd, don haka a gyara tsarin bisa ƙa'idar da mai amfani ya amince da ita kafin wallafa. Tarihi yana cikin memory ne kawai kuma zai ɓace idan an rufe app. AI/online mode bai haɗu da sabis ba tukuna.

## Yadda ake samar da APK
1. Shigar da Android Studio (version mai goyon bayan Android Gradle Plugin 8.7.3).
2. Buɗe wannan folder a Android Studio.
3. Bari Gradle Sync ya kammala; ana buƙatar intanet sau ɗaya don sauke dependencies.
4. Zaɓi Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK na debug zai kasance a `app/build/outputs/apk/debug/app-debug.apk`.

Don APK na rarrabawa: Build > Generate Signed Bundle / APK, sannan ƙirƙiri keystore ka adana shi a wuri mai tsaro. Kada a raba keystore ko password.

## Abubuwan da za a yi kafin sakin jama'a
- Tabbatar da ƙa'idar ramli da tushen fassara
- Ajiye tarihi ta Room/DataStore idan ana so
- Idan za a ƙara AI, yi amfani da backend mai tsaro; kada a saka API key a cikin APK
- Gwada a na'urorin Android daban-daban
- Ƙara privacy policy idan za a tattara ko aika bayanai
